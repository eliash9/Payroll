<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\PdfServiceProvider::class,
    Laravel\Breeze\BreezeServiceProvider::class,
];
