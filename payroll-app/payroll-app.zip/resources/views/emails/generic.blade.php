<!DOCTYPE html>
<html>
<head>
    <title>{{ $subject }}</title>
</head>
<body>
    {!! nl2br(e($body)) !!}
</body>
</html>
