<img src="{{ asset('images/logo.png') }}" {{ $attributes }} alt="Logo" />
